# 油字幕 - 本地 AI Vtuber 即時字幕

**V-Translate - Real time local AI translator for Vtuber viewers**

**Windows v0.4.4 測試版：[直接下載 ZIP](https://github.com/CookieProduction853/V-Translate/raw/refs/heads/main/downloads/V-Translate-v0.4.4-Windows-x64.zip)** · 解壓後開啟 `V-Translate.exe`，不用安裝 Python。

v0.4.4 Windows 測試版採用新提供的程式圖示，新增 720p／1080p／1440p／來源解析度的擷取畫質選擇，並將語言與播放設定放在 AI 引擎設定上方。畫質選擇與 AI 配置分開；擷取後顯示實際解析度，不能把低解析度來源變成真正高清。贊助區會輪播預留卡片與可用圖片，啟動時嘗試檢查 `cookieproduction853.github.io/V-Translate/ads/manifest.json`；Pages 設定及部署尚未完成，目前可使用隨程式附帶的圖片。離線時使用已快取的圖片或預留卡片。廣告素材放在 V-Translate 儲存庫的 `assets/ad`，發佈方法見[圖片廣告說明](docs/adverts.md)。

AI 音訊積壓時會暫停播放並倒數，依配置及最近處理速度預計等待 20–120 秒；擷取及 AI 處理繼續，倒數後恢復。詳見[播放恢復說明](docs/playback-recovery.md)及[廣告與贊助說明](docs/monetization.md)。

以 Rust 製作的本機直播字幕播放器，可選 CPU 或 Vulkan 顯卡執行 AI 翻譯。先辨識原文、翻譯，再延遲播放擷取的影音，讓字幕依播放器時間顯示。使用者不需要安裝 Python，也不需要提供雲端 AI API 金鑰。

這個版本採用「Windows 程式 + 本機瀏覽器播放器」：程式負責模型、辨識與翻譯，Chrome／Edge 負責擷取已開啟的直播分頁和播放緩衝影音。它不會安裝另一套瀏覽器。

## 使用方式

1. 解壓 Windows 套件，開啟 `V-Translate.exe`，保留程式執行。它會開啟本機播放器；頁首可切換「繁體中文／English」。
2. 在「CPU／顯卡選擇」選擇 CPU 或顯卡 Vulkan。AMD Radeon（包括 RX 9070）及 NVIDIA GeForce 用家可選 Vulkan；有多張顯卡時，可偵測後指定要用的裝置。右側「翻譯模型」預設是內建 Qwen，也可使用[自訂 GGUF 翻譯模型](docs/custom-models.md)。再按右上角「準備 AI 模型」，先選配置與 Whisper 大小、確認後才下載；也可開啟「效能設定」手動調整。首次會下載所需引擎與模型；之後重用已下載的檔案。辨識及翻譯均在電腦上執行。
3. 使用同一個 Chrome 或 Edge 開啟直播。會限直播請先在原網站登入有觀看權限的帳號，確認原分頁已正常播放。
4. 在油字幕選擇原文語言與翻譯語言，開始擷取。瀏覽器詢問分享內容時，選擇**直播分頁**並勾選**分享分頁音訊**。
5. 等候影音緩衝及第一批字幕產生。之後從油字幕播放器觀看，原直播分頁請保持開啟。
6. 開始前可設定起始緩衝，播放時可微調字幕時間或切換原文顯示。結束時先按「結束擷取」，再按下方的大按鈕「關閉背景聽寫程式(whisper)」；只關閉播放器視窗時，背景 AI 引擎會在約 3 分鐘內關閉。

**請用 Chrome／Edge 開啟播放器。** Firefox 對分頁音訊擷取的支援不足，這個版本不將 Firefox 的直播聲音擷取列為支援功能。分享整個螢幕或視窗也可能沒有聲音，請優先選擇瀏覽器分頁。

## 更新後仍看到舊版介面或圖示

v0.4.4 的頁面左上角會顯示版本號，右側播放與語言設定下方的「字幕設定」有「CPU／顯卡選擇」。選「顯卡 Vulkan」後才會顯示「翻譯顯卡」及「偵測顯卡」。

若畫面沒有版本號或顯卡選項，請在舊播放器按「關閉本機程式」（早期版本在頁面最下方，新版名稱為「關閉背景聽寫程式(whisper)」），再解壓並開啟最新套件裡的 `V-Translate.exe`。只按視窗右上角 X 可能讓舊程式繼續在背景執行。既有模型會保留，不用刪除資料目錄。新版會檢查背景程式版本，避免重新開到舊版介面；不會強制中止舊版正在進行的擷取。

v0.4.4 已嵌入 `assets/TASK BAR ICON.png` 圖示，供播放器頁首、分頁及 Windows 程式／視窗／工作列使用。更新時先關閉舊背景程式，再開啟新版；若確認已是 v0.4.4 而 Windows 釘選圖示仍未更新，取消釘選舊捷徑，再從新版重新釘選。

## 介面設計與常用按鈕

v0.4.1 提供繁體中文（zh-Hant）／English（en）介面及兩款主題。頁首可直接切換，語言、主題和配置會保存在本機，重新開啟後沿用：

| 設計 | 外觀與使用方式 |
| --- | --- |
| Dark（studio） | 深色工作室介面，保留播放器與設定並排的配置。 |
| Daylight（light） | 明亮介面，適合白天或喜歡淺色背景的用家。 |

切換主題不需要重新下載模型。「關閉背景聽寫程式(whisper)」是播放器左側、「結束擷取」下方的大按鈕；結束觀看時先停止擷取，再關閉背景程式。

頁面上方的「模型資料夾」按鈕會在系統檔案管理員開啟 `models` 資料夾，方便查看模型或自行刪除。**按鈕本身不會刪除任何檔案。** 如要刪除，請先開啟資料夾，再結束擷取並按「關閉背景聽寫程式(whisper)」，等引擎退出後才刪除，避免檔案仍在使用中。移除模型後，下次準備 AI 時可能需要重新下載；詞彙包和程式設定另行保存。

## VTuber 詞彙包

可匯入 JSON 詞彙包、常見 CSV／TSV 詞彙表或每行一詞的 TXT，選取後讓語音引擎參考人名、讀音與口頭禪，讓翻譯模型參考指定譯名。每個詞彙包最多 128 個詞條、64 KiB，支援保存、切換及移除。匯入後要從清單明確選取才會啟用；更換前先結束擷取。

參閱 [詞彙包格式及使用方法](docs/vocabulary.md)，或下載 [虛構 VTuber 示例詞彙包](examples/vtuber-vocabulary.json)。這是提示詞與詞彙參考功能，沒有重新訓練模型，也不保證辨識精準度提高。別人訓練好的 `.bin`、`.gguf`、`.safetensors` 或 LoRA 檔案不能直接透過詞彙包匯入器使用，還需要確認架構及格式。

## 自訂 GGUF 翻譯模型

可在右側「翻譯模型」選用自行取得的單一 `.gguf` 翻譯模型。先結束擷取，按「開啟自訂模型資料夾」，把完整檔案直接放入 `%LOCALAPPDATA%\LiveSub\LiveSub\data\models\translation`，按「重新掃描」後，在「翻譯模型」選取檔案；選擇會自動儲存，再按「準備 AI 模型」。模型必須是 llama.cpp b8500 可載入的 chat／instruct 類型；分割 GGUF、LoRA、`.safetensors` 或詞彙包不能代替完整模型。

內建 Qwen 仍是預設選項，低配置自動用 0.5B，中／高配置用 1.5B。選用自訂模型後，只會自動下載所需引擎及 Whisper，不會另外下載 Qwen。CPU 可先考慮約 1–3B 的 Q4_K_M 模型；這只是資源用量的起點，不保證翻譯品質或即時速度。模型架構不支援、記憶體不足或載入失敗時會顯示錯誤，請另選模型後重新準備。

介面的「尋找翻譯模型（Ollama） ↗」會在新分頁開啟 [Ollama 翻譯模型搜尋頁](https://ollama.com/search?q=translate)。它不是 Ollama API 連線功能；Ollama 套件或 `Modelfile` 不保證能直接複製使用，須另外取得同一模型、相容架構的 GGUF 檔案。完整操作、相容性及校驗方式見[自訂模型說明](docs/custom-models.md)。

## CPU、AMD 與 NVIDIA 顯卡翻譯

v0.2.0 加入用家可選的翻譯運算模式：

| 模式 | 聽寫原文 | AI 翻譯 | 適用情況 |
| --- | --- | --- | --- |
| CPU | CPU Whisper | CPU 翻譯模型 | 不使用顯卡，保留原有模式 |
| 顯卡 Vulkan | CPU Whisper | Vulkan 顯卡翻譯模型 | AMD Radeon／NVIDIA GeForce 等有相容 Vulkan 驅動的顯卡 |

**顯卡模式加速的是翻譯，語音聽寫仍由 CPU 執行。** 兩個模式共用同一套模型；切換模式不需要重下載模型，但首次選 Vulkan 需要下載對應的 llama.cpp 引擎。Vulkan 模式不需要 CUDA、ROCm 或 Vulkan SDK。

AMD RX 9070 用家請先安裝支援該顯卡的最新 AMD Adrenalin 驅動，然後選擇「顯卡 Vulkan」。可使用裝置偵測功能查看驅動實際提供的 Vulkan 裝置；多顯卡電腦可指定 RX 9070。自動選擇會使用偵測到的可用裝置，請留意就緒狀態顯示的實際名稱。

開始擷取前設定模式；若正在觀看，先「結束擷取」才切換。設定會保存，重新開啟後沿用。切換會重新載入引擎；完成前不能開始 AI 字幕。

GPU 初始化必須確認有模型層載入 Vulkan 後端才顯示就緒。若驅動、顯存或引擎啟動出錯，程式會顯示原因，不會把 CPU 運算冒充為顯卡加速；可手動切回 CPU，再按「準備 AI 模型」。

RX 9070 是本功能的目標裝置，**目前尚未在 RX 9070 真機驗證相容性或效能**，不承諾特定加速倍數或字幕延遲。

## 下載前選配置與 Whisper 大小

首次使用預設為「高」：Whisper Small、6 個 CPU 執行緒、5 秒音訊片段及 20 秒起始緩衝。已有設定會沿用，不會因更新被改成高配置。按右上角「準備 AI 模型」可先選配置，再確認下載；配置亦可重新開啟並手動調整。顯卡選擇獨立保留，不會因套用配置而替你改選另一張卡。

| 建議配置 | 目標電腦示例 | Whisper | CPU 執行緒 | 音訊片段／起始緩衝 | 內建翻譯模型 |
| --- | --- | --- | --- | --- | --- |
| 低 | i5-8250U／內顯 | Tiny，約 75 MB | 2 | 8 秒／60 秒 | Qwen 0.5B，品質較低 |
| 中 | Ryzen 5 3600X／16GB／1660 Ti | Base，約 148 MB | 3 | 6 秒／35 秒 | Qwen 1.5B |
| 高 | Ryzen 7 5800X3D／32GB／RX 9070 | Small，約 488 MB | 6 | 5 秒／20 秒 | Qwen 1.5B |

低／中／高配置均保留；若電腦卡頓，可改選中或低，再準備對應模型。自訂翻譯模型獨立保留，套用配置不會把它換回 Qwen。這些是起始建議，尚未在上述三台電腦實測，不是即時速度保證。可以手動選 Tiny／Base／Small、1–8 個執行緒、4–12 秒音訊及 10–120 秒起始緩衝；緩衝不能短於音訊片段。低配置也降低瀏覽器影音擷取規格，以減輕編碼負載。較小的 Whisper／翻譯模型通常較省資源，但可能漏字、錯認或誤譯。

Whisper CPU 使用率高可能是運算中的正常現象；減少執行緒及使用 Tiny 能降低並行負擔，不能保證固定 CPU 百分比。緩衝以秒計，並受記憶體上限保護；若持續處理速度慢於來源，增加一次性的緩衝也無法永久解決。

## AI 失敗時保留播放器

舊版的「翻譯超過長度限制」來自文字引擎的 `finish_reason: length`：譯文達到每次 384 token 的輸出上限，舊版把它當成致命錯誤。新版會拆短重譯；網路／HTTP 等暫時性翻譯錯誤會稍候重試。仍失敗時保留原文及警告，下一段繼續。

AI 請求暫時失敗也不會因此結束擷取：播放器保留，等待及重試；必要時重新載入已有引擎。勾選「等待字幕完成再播放」會暫停影音等字幕，未勾選就繼續播放。長時間故障時，為限制緩衝記憶體，可能先繼續無字幕播放並顯示提示。來源分享結束或瀏覽器影音編碼器失敗仍需要重新選取來源。

## 會限直播與同步的意思

油字幕讀取你明確分享、且瀏覽器已能播放的畫面與聲音。登入、會員資格與直播播放均由原網站處理，不需要交出 Cookie 或密碼，也不需要貼會員影片下載網址。若網站或 DRM 禁止擷取，可能出現黑畫面或無聲；程式不繞過這類限制。

語音辨識需要累積一段聲音，本機翻譯也需要時間，因此無法同時承諾零延遲和即時譯文。本程式讓影音一起落後直播，再把字幕放在對應的播放時間。緩衝按配置建議為 20／35／60 秒，可手動調整；實際需要的延遲取決於 CPU／顯卡、模型、語速與直播音質。處理速度持續跟不上時，應增加延遲，或等待字幕後再播放。

辨識錯誤、歌曲、多人同時說話、VTuber 名字，以及翻譯模型的誤譯都可能發生。字幕是 AI 產生的參考內容。分享開始時瀏覽器編碼器與音訊擷取的起始時間也可能有少量偏移；不宣稱逐影格同步。

## 電腦與下載需求

- Windows 10／11 64 位元、Chrome 或 Edge。
- 若啟動引擎顯示缺少 DLL，請安裝 [Microsoft Visual C++ x64 Runtime](https://aka.ms/vs/17/release/vc_redist.x64.exe)，然後重新開啟程式；不需要 Python。
- 建議 16 GB 記憶體；語音模型和翻譯模型會消耗數 GB，瀏覽器另需緩衝空間。
- 建議保留至少 4 GB 可用磁碟空間供模型與引擎下載。具體大小以首次下載畫面為準。
- 首次設定需要網路，來源為 GitHub、Hugging Face 及其下載端點。完成後，AI 推論不會把聲音或字幕送到雲端；直播網站本身仍需要連線。
- 本機網頁只由程式在 loopback 介面提供。不要把含有存取 token 的播放器網址分享給其他人。

程式不提供錄影保存或直播下載功能。緩衝影音只用於本次播放；停止後會釋放。字幕紀錄可匯出為 SRT。

為保留舊版模型與設定，資料目錄沿用 `%LOCALAPPDATA%\LiveSub\LiveSub\data`，結束程式後仍可重用。該目錄中的 `vocabularies` 存放詞彙包與選擇，`models` 存放模型與校驗資訊，`runtime` 存放 CPU／Vulkan 引擎，`logs` 存放引擎啟動紀錄；可透過 `V-Translate.exe --data-dir "D:\V-Translate-data"` 改變資料位置。

Whisper 聽寫可選 Tiny／Base／Small；內建翻譯使用 Qwen2.5-Instruct Q4_K_M，低配置為 0.5B，中／高配置為 1.5B，也可選用自行提供的相容 GGUF。只下載目前需要的模型，已下載的模型會重用；自訂模型不由程式下載。Windows 自動下載的執行引擎為 whisper.cpp v1.7.6（CPU）與 llama.cpp b8500（CPU 或 Vulkan）；內建模型會依發布者的 SHA256 驗證並記錄確切版本。自訂檔案的本機校驗方式見[自訂模型說明](docs/custom-models.md)。

## 自行編譯

開發者需要 Rust 1.89 或更新的穩定版。Windows 建議使用 MSVC 工具鏈，並安裝 Visual Studio Build Tools 的「使用 C++ 的桌面開發」與 Windows SDK。使用者執行已編譯程式時不需要 Rust 或 Python。

```powershell
cargo build --locked --release
.\target\release\livesub.exe
```

Linux 開發環境可執行 Rust 後端的建置與測試。若要在 Linux 實際載入模型，須另外將自行建置的官方 `whisper-server` 和 `llama-server` 分別放入資料目錄的 `runtime/whisper/` 與 `runtime/llama/`，並保留所需動態函式庫。Vulkan 翻譯另需有 Vulkan 支援的 `llama-server` 放入 `runtime/llama-vulkan/`；自動引擎下載目前只支援 Windows x64。Windows 推論執行檔和瀏覽器擷取功能仍需在 Windows 實際驗證。

```sh
cargo fmt --all -- --check
cargo test --locked
cargo clippy --locked --all-targets -- -D warnings
node web/timeline.test.mjs
node web/backpressure.test.mjs
```

`.github/workflows/release.yml` 可手動執行，也會在推送 `v*` 標籤時建立 Windows 套件，於該次 Actions 執行的 artifacts 下載。此流程不會自動建立公開 GitHub Release。Windows 套件未簽章；不要把成功編譯等同於所有電腦、所有直播都已通過測試。

## 問題排查

| 情況 | 處理方式 |
| --- | --- |
| 沒有聲音或無法辨識 | 確認選的是直播分頁且勾選分享音訊；原網站須能正常播放。停止後重新分享。 |
| 畫面黑屏 | 先確認原網站可正常播放。DRM 或平台擷取限制無法由本程式解除。 |
| 字幕持續落後 | 增加延遲，關閉其他吃 CPU 的程式；CPU 無法長期跟上時，較大的固定緩衝也不能永久解決。 |
| 聽到兩份聲音 | 只保留播放器的輸出；瀏覽器的原分頁音訊抑制能力因版本不同，請檢查分享與音訊設定。 |
| 模型下載失敗 | 檢查網路、可用空間與畫面的錯誤訊息後重試。程式不會要求關閉 TLS 或校驗檢查。 |
| 自訂模型不在清單或載入失敗 | 確認是直接放入自訂翻譯資料夾的單一完整 `.gguf`，重新整理清單；架構須相容 llama.cpp b8500，且電腦須有足夠記憶體。另選模型或內建 Qwen，再準備 AI。詳見[自訂模型說明](docs/custom-models.md)。 |
| 原文有了但譯文未完成 | 文字模型仍在本機計算；可等候、增加播放延遲，或使用相容顯卡的 Vulkan 模式。 |
| 找不到 Radeon／GeForce／Vulkan 裝置 | 更新 AMD Adrenalin 或 NVIDIA 驅動，重新偵測裝置；確認選擇的是獨立顯卡。仍失敗時可切回 CPU。 |
| Vulkan 啟動失敗或沒有確認 GPU 載入 | 查看畫面錯誤與資料目錄的 `logs`；更新驅動、關閉占用顯存的程式，或手動改用 CPU 再準備模型。 |

目前功能與限制以實際程式和驗證結果為準；專案尚未宣稱已在實際會員直播完成端到端驗證。

## 授權

程式碼採 [MIT](LICENSE) 授權。推論引擎、模型與 Rust 相依套件請參閱 [第三方聲明](THIRD_PARTY_NOTICES.md)。

## 驗證範圍

本次在 Linux 雲端完成 Windows x64 交叉編譯、Rust 測試及靜態檢查，並用 Chromium 的真正錄製與播放管線驗證緩衝、字幕時間軸、慢速推論等待、SRT 匯出及停止清理。瀏覽器測試使用合成影音及測試推論回應。

CPU／Vulkan 模式選擇、裝置解析、模型清單與載入檢查等自動測試用於驗證控制流程；測試替身與 GGUF 測試檔案不等於真實模型推論。目前雲端沒有 RX 9070 或 Windows 顯卡環境，且 Hugging Face 存取被網路政策阻擋，因此未將 Windows 真機、RX 9070 效能、真正模型辨識／翻譯、自訂模型相容性或實際會員直播端到端驗證列為已通過。Windows 桌面上的圖示外觀亦尚未真機確認。提供的 `.exe` 為 v0.4.1 測試版。

## NVIDIA GeForce 使用方式

v0.2.2 在介面明確標示 AMD／NVIDIA，兩者均使用 Vulkan 後端。NVIDIA 用家請安裝支援該顯卡的最新 NVIDIA Game Ready 或 Studio 驅動，選「顯卡 Vulkan」→「偵測顯卡」→選取 NVIDIA GeForce →「準備 AI 模型」。不需要另外安裝 CUDA Toolkit；本版本未提供獨立 CUDA 後端。

多品牌顯卡可在同一列表選取，模型與 CPU／AMD 模式共用。翻譯使用所選顯卡，聽寫仍使用 CPU。已加入 NVIDIA 裝置解析、指定裝置及 GPU 載入檢查測試，尚未在 NVIDIA 真機驗證相容性或效能。

兩款主題的完整預覽見 [介面設計](docs/ui-designs.md)，可在程式內直接選擇，不需要重新下載不同程式。

## 聯絡與功能建議

歡迎提出功能需求、回報問題或洽談合作：[vtranslate853@gmail.com](mailto:vtranslate853@gmail.com)。

Power by 曲奇 @Cookie Production · Instagram：[@cookie_production](https://www.instagram.com/cookie_production/)。
