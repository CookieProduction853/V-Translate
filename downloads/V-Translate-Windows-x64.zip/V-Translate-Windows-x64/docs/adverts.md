# 廣告圖片與贊助輪播

v0.4.4 Windows 測試版可在廣告／贊助版位顯示專案提供的靜態廣告圖片，與原有合作邀請卡片輪播。這是直接贊助的圖片展示功能，沒有接入即時廣告網絡，也不會自動產生廣告收入。合作與一般用戶要求可來信 [vtranslate853@gmail.com](mailto:vtranslate853@gmail.com)。

## 播放器中的顯示方式

輪播每 8 秒切換一次，包含合作邀請卡片及已成功載入的廣告。版位約 250 px 高，手機會按版面稍作調整；圖片會等比例填滿並裁切邊緣，請把重要文字與標誌留在中央安全範圍。

按廣告圖片會在新分頁開啟其連結，不會自動開啟網站。合作邀請卡片保留贊助聯絡按鈕。可使用版位的暫停按鈕停止輪播；滑鼠停留、鍵盤焦點位於版位內或分頁隱藏時，也會暫停計時。

## 準備廣告圖片與連結

廣告來源放在 [CookieProduction853/V-Translate](https://github.com/CookieProduction853/V-Translate) 儲存庫的 `assets/ad`。新增時，請將圖片與連結文字檔使用相同檔名主體，例如：

```text
assets/ad/AD2.jpg
assets/ad/AD2.url
```

`.url` 是純文字檔，內容填入一個完整的 HTTPS 網址，例如 `https://example.com/sponsor`；也接受 Windows Internet Shortcut 的 `[InternetShortcut]` 與 `URL=https://…` 格式。只允許 HTTPS 網站連結，不接受含帳號密碼的網址或 `javascript:`、`data:`、`file:` 等連結。現有 PNG 圖片亦可使用；缺少配對、連結不合格或圖片損壞的項目會略過。

維護者可執行 `node scripts/build-ad-feed.cjs` 產生廣告清單與套件內圖片資料。只修改本機檔案不會更新別人的播放器；隨程式附帶的圖片需要更新套件，遠端圖片則需完成以下 Pages 發佈。

## 發佈公開廣告來源

程式預設檢查的清單網址為：

```text
https://cookieproduction853.github.io/V-Translate/ads/manifest.json
```

儲存庫內的 [ad-pages.yml 工作流程](../.github/workflows/ad-pages.yml) 使用 [build-ad-pages.cjs](../scripts/build-ad-pages.cjs) 產生 `dist/ad-pages`，只發佈廣告圖片、清單與簡單首頁，不會把應用程式原始碼或模型放到 Pages 網站。

1. 儲存庫擁有人先到 **Settings → Pages → Source**，選擇 **GitHub Actions**。這是一次性的設定；目前尚未完成。私人個人帳號儲存庫的 Pages 需要符合 GitHub 方案資格，請先確認帳號可使用。
2. 將配對圖片與 `.url` 放入 `assets/ad` 後，更新到 `main`；工作流程會因相關檔案變更執行。也可在 **Actions → Publish public advertisement assets → Run workflow** 手動執行。
3. 工作流程成功後，確認上述清單及其中圖片不需登入即可讀取。播放器在下次啟動時檢查更新。

本機可執行 `node scripts/build-ad-pages.cjs` 檢查產生結果。儲存庫可以保持私有，供播放器使用的 Pages 廣告檔案則必須公開可讀。

## 更新、快取與失敗處理

程式啟動後會在背景檢查上述 GitHub Pages 廣告清單，驗證圖片後存入資料目錄的 `ads` 快取，播放器從本機程式讀取圖片。遠端來源啟用後，更新廣告不需要重新下載整個 Windows 套件。

**目前 Pages 設定及遠端部署尚未完成，不能視為已啟用自動更新。** 現有隨附圖片仍可離線輪播；完成上述設定及部署後，才能提供遠端廣告更新。

網路離線或更新失敗時，會繼續使用已驗證的快取或套件內圖片。無法使用的圖片與連結會略過；沒有可用廣告時，只顯示合作邀請卡片。空清單不會產生空白或損壞的廣告連結。

這個功能沒有曝光／點擊統計、追蹤腳本或廣告成效回報，也不會上傳使用者的觀看內容、字幕或個人資料。按廣告後開啟的外部網站，由該網站自行提供服務。
